# AndTroj
A tool for integrating the Metasploit payload with Android's healthy programs and bypassing antivirus


- :heavy_check_mark: Using custom dns for harvester phishing webpages(license Pro Ngrok).
- :heavy_check_mark: Send Phonelist for sms spoofing(license Pro twilio).
- :heavy_check_mark: Use Harvesting phishing page and BeEF-XSS Access(Hook js payload).
- :heavy_check_mark: Bypass 90% Android Antivirus(Obfuscation Method).
- :heavy_check_mark: Bind metasploit meterpreter payload(android) Original APKs.
- :heavy_check_mark: Anti Forensic connections in targets(using tor ips for ngrok connections).
- :heavy_check_mark: Create Automations persistence and bash backdoor for android phones.


# Main Menu...

![alt text][logo]

[logo]: https://raw.githubusercontent.com/unk9vvn/AndTroj/master/ATJ.jpg "Logo Title Text 2"


This tool creates a tune-up of the Metasploit program, unlocks the program and integrates it into the footage. During this operation, the vagaries are mimicking the unpacking Android antivirus and compiling it after the completion of the integration. For the program's service, it's one-on-one and rearwards automatically after getting back access on Android OS Bargas And it runs to allow the service to be activated every hour, all of which is done automatically

# Social Engineering Menu...

![alt text](https://raw.githubusercontent.com/unk9vvn/AndTroj/master/SEA.jpg)


After completing the build-in program that intercepts itself, I will show you the social engineering methods that can be sent to the victim in three ways. A Web SpearPhishing is website and another way through Sending Spoof SMS link download RAT to content sms.

# How to Run
```
# git clone https://github.com/unk9vvn/AndTroj.git
# cd AndTroj && chmod 755 atj.py
# pip2 install -r requirements.txt
# ./atj.py

After Running
# atj
```
# Only supports the Kali Linux 2018 operating system

# Telegram channel: [Unk9vvN](https://t.me/Unk9vvN)
